GetNormalizedMat<-function(Data, Sizes){
Out=t(t(Data)/Sizes)
Out}
