
QuantileNorm=function(Data, Quantile){
	QtilePt=apply(Data, 2, function(i)quantile(i, Quantile))
	Size= QtilePt * prod(QtilePt) ^ (-1/ncol(Data))
	Size
	}

