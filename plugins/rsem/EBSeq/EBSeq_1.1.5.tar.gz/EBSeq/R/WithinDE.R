WithinDE=function(Data,maxround=5){
	Res=vector("list",choose(ncol(Data),2))
	DEprop=matrix(0,nrow=ncol(Data),ncol=ncol(Data))
	colnames(DEprop)=rownames(DEprop)=colnames(Data)
	Sizes=MedianNorm(Data)
	for(i in 1:(ncol(Data)-1)){
			for(j in (i+1):ncol(Data)){
			EBStart=EBTest(Data[,c(i,j)],
				   sizeFactors=Sizes[c(i,j)],
				   Conditions=as.factor(1:2),maxround=maxround)
			Res[[i]]=EBStart
			names(Res[[i]])=paste(i,"vs",j,sep="")
		DEprop[i,j]=DEprop[j,i]=EBStart$P[maxround]
	}}
Out=list(results=Res, DEprop=DEprop)
}
