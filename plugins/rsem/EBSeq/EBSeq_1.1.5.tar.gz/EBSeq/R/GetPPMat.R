GetPPMat <- function(EBout){
	PP=EBout$PPMat	
}
