
PlotTree=function(OptTerm,OptDist){
Length=length(OptTerm)
data=matrix(rnorm((Length+1)^2,0,1),ncol=(Length+1))
dd=dist(data)     
hc <- hclust(dd, "ave")


Names=OptTerm[[Length]]
Order=1:(Length+1)
Ht=rep(0,Length)
for(i in 1:Length){
	for(j in 1:Length)
	if(length(setdiff(OptTerm[[i]],OptTerm[[j]]))==0) Ht[i]=Ht[i]+OptDist[[j]]
}

Mer=matrix(0, ncol=2, nrow=Length)
Mer[1,1]=-which(Names==OptTerm[[1]][1])
Mer[1,2]=-which(Names==OptTerm[[1]][2])

for(i in 2:Length){
	tmp=NULL
	for(j in 1:(i-1)){
	if(length(setdiff(OptTerm[[j]],OptTerm[[i]]))==0)tmp=c(tmp,j)
	
	}
	if(!is.null(tmp)){
		t2=max(tmp)
		p2=OptTerm[[t2]]
		p1=setdiff(OptTerm[[i]],OptTerm[[t2]])
		if(length(p1)==1)t1=-which(Names==p1)
		if(length(p1)!=1){
			for(k in tmp){
				if(identical(OptTerm[[k]],p1))t1=k
			}
			
		}
		Mer[i,1]=t1
		Mer[i,2]=t2
	}
	if(is.null(tmp)){
		t2=which(Names==OptTerm[[i]][2])
		t1=which(Names==OptTerm[[i]][1])
		Mer[i,1]=-t1
		Mer[i,2]=-t2
	}
}

hc[[1]]=Mer
hc[[2]]=max(Ht)-Ht
hc[[3]]=Order
hc[[4]]=Names

plot(hc)

hc
}
