GetPP <- function(EBout){
	#PP=c(EBout[[5]], EBout[[6]])
	PP=EBout$PPDE	
}
